DarkGradient free sampler - 5 of the 40 LUTs.

Colour-managed? No. Creative looks, applied after primary correction.
Load: Resolve LUT browser, Premiere Input LUT, ffmpeg lut3d.

Full pack (40 LUTs, 5 groups, generator): see the store.
Licence: free to use in any project, including commercial. Do not resell.
(c) S. B. Masud
