IRIS free sampler - 20 of the 150 SVG assets.

Pure SVG, fixed viewBox, opens in Illustrator, Inkscape, Figma, browser.
Full pack (150 assets, 5 categories, seeds + generator): see the store.
Licence: free to use in any project, including commercial. Do not resell.
(c) S. B. Masud
